SONU CRACKERS PROMO: CAPCUT PACK (9:16, 32 sec, 60fps)

Folders
1_clips      16 clips, ready cut and in order (clip_01 ... clip_16). No text, no audio. Replace any of them.
2_text_png   15 text overlays, transparent PNG, 2160x3840. They are separate from the clips.
3_audio      vo_v1.mp3 (voice over), song_maruti_from_31.6s.mp3 (song, separate), reference_mix (for checking only)
4_fonts      Anton (hero words) and Inter ExtraBold (small words). Install both before using native text.
TIMELINE.csv exact start/end of every clip, text and audio on the timeline.

How to put it together in CapCut (project 9:16, 60fps)
1. Main track: drop the clips in order, one after another. Each clip is already the right length.
2. Overlay track above: drop each text_XX.png at its start time from TIMELINE.csv, set its length from the CSV.
   Add CapCut animation: In = Slide up / Fade, Out = Fade, about 0.2s. Do NOT use shake or pulse.
3. Audio track 1: vo_v1.mp3 at 0:00. Audio track 2: the song at 0:00. Song volume low (~35%) until 4.3s, then raise it and lower it under the voice over. Fade out the last 2 seconds.
4. To replace a clip: select it, Replace clip, keep the same length. Text stays untouched because it is on its own track.
5. If you want editable CapCut text instead of PNG: use the words in the TIMELINE.csv note column, fonts from 4_fonts, hero word in orange-gold gradient, small words white with a soft shadow, placed in the lower third (never on faces).

Notes
- The song is copyrighted. For posting, add it from Instagram's library instead.
- clip_01 is the AI hook (720p, Kling); it is not upscaled. All the others are 4K60.
- A real CapCut draft file cannot be generated here, so this pack is the layers CapCut can import.
