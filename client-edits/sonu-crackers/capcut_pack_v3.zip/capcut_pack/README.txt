SONU CRACKERS PROMO v3: CAPCUT PACK (9:16, 32 sec, 60fps)

Folders
1_clips      16 clips, already cut, in order (clip_01 ... clip_16). No text, no audio. Replace any of them.
             Shaky shots were swapped for steadier ones. clip_06 (Whistling Wheel) is stabilised and slowed; clip_07 (Lagan) uses only the one-direction part. Both slow-mos use motion interpolation (no stutter).
             A gentle 5% zoom in / zoom out is already baked into clips 02-16 (alternating).
2_text_png   15 text overlays, transparent PNG, 2160x3840. Separate from the clips.
3_audio      vo_v2_processed.mp3  voice over (cleaned, ready)
             song_v2_ducked.mp3   song, separate track, already lowered under the voice over
             vo_raw.mp3 / song_raw_from_31.6s.mp3  untouched versions, if you want to mix yourself
             reference_mix_v2.mp3 how the final should sound (for checking only)
4_fonts      Anton (hero words) and Inter ExtraBold (small words).
TIMELINE.csv exact start/end of every clip, text and audio.

How to put it together in CapCut (project 9:16, 60fps)
1. Main track: clip_01 ... clip_16 in order, one after another, no gaps.
2. Overlay track: each text_XX.png at its start time from TIMELINE.csv, length from the CSV.
   Animation: In = Slide up / Fade, Out = Fade, about 0.2s. No shake or pulse.
3. Audio: vo_v2_processed.mp3 and song_v2_ducked.mp3, both at 0:00 on separate tracks, both at 100%.
   Do not raise the song: it is set so the voice stays clearly on top.
4. To replace a clip: select it > Replace, keep the same length. Text stays on its own track.

Notes
- The song is copyrighted. For posting, add it from Instagram's library instead.
- clip_01 is the AI hook (720p). All others are 4K60.
- A real CapCut draft file cannot be generated here, so this pack is the layers CapCut can import.
